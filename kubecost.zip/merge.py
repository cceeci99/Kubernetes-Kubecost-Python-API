import json
import requests
import glob, os
import pandas as pd
import datetime as dt


data_path = 'data/'
csv_files = glob.glob(os.path.join(data_path, '*.csv'))

df = pd.concat(map(pd.read_csv, csv_files), ignore_index=True)

cpuCost = df.groupby(['Namespace'])['CpuCost'].sum().reset_index()
gpuCost = df.groupby(['Namespace'])['GpuCost'].sum().reset_index()
ramCost = df.groupby(['Namespace'])['RamCost'].sum().reset_index()
pvCost = df.groupby(['Namespace'])['PvCost'].sum().reset_index()
networkCost = df.groupby(['Namespace'])['NetworkCost'].sum().reset_index()
sharedCost = df.groupby(['Namespace'])['SharedCost'].sum().reset_index()
totalCost = df.groupby(['Namespace'])['TotalCost'].sum().reset_index()



final = pd.concat([cpuCost, gpuCost, ramCost, pvCost, networkCost, sharedCost, totalCost], ignore_index=True)
print(final)